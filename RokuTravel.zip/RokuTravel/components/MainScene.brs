sub init()
    ' Print initialization message
    ? "MainScene init()"
    
    ' Get references to UI elements
    m.titleScreen = m.top.findNode("titleScreen")
    m.countryGuide = m.top.findNode("countryGuide")
    m.countryCarousel = m.top.findNode("countryCarousel")
    
    ' Set up the country carousel
    setupCountryCarousel()
    
    ' Set initial focus on carousel
    m.countryCarousel.setFocus(true)
    
    ' Listen for carousel item selection
    m.countryCarousel.observeField("itemSelected", "onCountrySelected")
    
    ' Listen for back to menu from CountryGuide
    m.countryGuide.observeField("backToMenu", "onBackToMenu")
end sub

sub setupCountryCarousel()
    ' Create content node for the carousel
    content = createObject("roSGNode", "ContentNode")
    
    ' Add Japan (functional)
    japanNode = content.createChild("ContentNode")
    japanNode.hdPosterUrl = "pkg:/images/japan_card.jpg"
    japanNode.title = "Japan"
    japanNode.ID = "japan"
    
    ' Add France (placeholder - not functional yet)
    franceNode = content.createChild("ContentNode")
    franceNode.hdPosterUrl = "pkg:/images/france_card.jpg"
    franceNode.title = "France"
    franceNode.ID = "france"
    
    ' Add Italy (placeholder - not functional yet)
    italyNode = content.createChild("ContentNode")
    italyNode.hdPosterUrl = "pkg:/images/italy_card.jpg"
    italyNode.title = "Italy"
    italyNode.ID = "italy"
    
    ' Set the content to the carousel
    m.countryCarousel.content = content
end sub

sub onCountrySelected()
    ' Get the selected item index
    selectedIndex = m.countryCarousel.itemSelected
    selectedItem = m.countryCarousel.content.getChild(selectedIndex)
    
    ? "Country selected: "; selectedItem.title
    ? "Country ID: "; selectedItem.ID
    
    ' Only Japan is functional for now
    if selectedItem.ID = "japan" then
        ' Switch to Japan screen
        m.titleScreen.visible = false
        m.countryGuide.visible = true
        m.countryGuide.countryName = "Japan"
    else
        ' Show "Coming Soon" message for other countries
        ? "Country not yet available: "; selectedItem.title
        ' Could add a dialog here in future
    end if
end sub

sub onBackToMenu()
    ' Return from CountryGuide to title screen
    if m.countryGuide.backToMenu = true then
        m.countryGuide.visible = false
        m.countryGuide.backToMenu = false
        m.titleScreen.visible = true
        m.countryCarousel.setFocus(true)
    end if
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    ' Handle key presses
    handled = false
    
    if press then
        ? "Key pressed: "; key
    end if
    
    return handled
end function

sub init()
    ' Initialize UI elements
    m.tabList = m.top.findNode("tabList")
    m.slideTitle = m.top.findNode("slideTitle")
    m.slideContent = m.top.findNode("slideContent")
    m.slideNumber = m.top.findNode("slideNumber")
    m.navHint = m.top.findNode("navHint")
    
    ' State tracking
    m.currentTab = 0
    m.currentSlide = 0
    m.inTabMode = true
    
    ' Tab configuration
    m.tabs = ["Language", "Cuisine", "Hotspots", "Etiquette", "Travel Info"]
    m.tabKeys = ["language", "cuisine", "hotspots", "etiquette", "travel"]
    
    ' Initialize data and UI
    initializeSlidesData()
    setupTabs()
    showSlide()
    
    ' Setup event handlers
    if m.tabList <> invalid then
        m.tabList.observeField("itemFocused", "onTabFocused")
    end if
    
    ' Observe visibility to set focus when shown
    m.top.observeField("visible", "onVisibilityChange")
end sub

sub onVisibilityChange()
    if m.top.visible = true then
        ' Set focus on tab list when CountryGuide becomes visible
        if m.tabList <> invalid then
            m.tabList.setFocus(true)
        end if
    end if
end sub

sub initializeSlidesData()
    m.slidesData = CreateObject("roAssociativeArray")
    
    ' Language slides - 3 slides
    languageSlides = []
    languageSlides.Push(createSlide("Essential Greetings", buildGreetingsContent()))
    languageSlides.Push(createSlide("Restaurant Phrases", buildRestaurantContent()))
    languageSlides.Push(createSlide("Getting Around", buildNavigationContent()))
    m.slidesData.language = languageSlides
    
    ' Cuisine slides - 4 slides
    cuisineSlides = []
    cuisineSlides.Push(createSlide("Sushi & Sashimi", buildSushiContent()))
    cuisineSlides.Push(createSlide("Ramen", buildRamenContent()))
    cuisineSlides.Push(createSlide("Street Food Favorites", buildStreetFoodContent()))
    cuisineSlides.Push(createSlide("Premium Experience", buildPremiumFoodContent()))
    m.slidesData.cuisine = cuisineSlides
    
    ' Hotspots slides - 4 slides
    hotspotsSlides = []
    hotspotsSlides.Push(createSlide("Tokyo Highlights", buildTokyoContent()))
    hotspotsSlides.Push(createSlide("Kyoto Temples", buildKyotoContent()))
    hotspotsSlides.Push(createSlide("Osaka & Beyond", buildOsakaContent()))
    hotspotsSlides.Push(createSlide("Mount Fuji & Nature", buildFujiContent()))
    m.slidesData.hotspots = hotspotsSlides
    
    ' Etiquette slides - 5 slides
    etiquetteSlides = []
    etiquetteSlides.Push(createSlide("Bowing & Greetings", buildBowingContent()))
    etiquetteSlides.Push(createSlide("Shoes & Indoor Spaces", buildShoesContent()))
    etiquetteSlides.Push(createSlide("Chopstick Etiquette", buildChopsticksContent()))
    etiquetteSlides.Push(createSlide("Public Behavior", buildPublicContent()))
    etiquetteSlides.Push(createSlide("Onsen (Hot Springs)", buildOnsenContent()))
    m.slidesData.etiquette = etiquetteSlides
    
    ' Travel slides - 5 slides
    travelSlides = []
    travelSlides.Push(createSlide("Best Times to Visit", buildTimingContent()))
    travelSlides.Push(createSlide("Budget Planning", buildBudgetContent()))
    travelSlides.Push(createSlide("Transportation", buildTransportContent()))
    travelSlides.Push(createSlide("Money & Essentials", buildMoneyContent()))
    travelSlides.Push(createSlide("Essential Apps & Tips", buildAppsContent()))
    m.slidesData.travel = travelSlides
end sub

function createSlide(title as String, content as String) as Object
    slide = CreateObject("roAssociativeArray")
    slide.title = title
    slide.content = content
    return slide
end function

' ========================================
' CONTENT BUILDER FUNCTIONS - LANGUAGE
' ========================================

function buildGreetingsContent() as String
    c = "Hello - Konnichiwa" + chr(10)
    c = c + "Thank you - Arigatou gozaimasu" + chr(10)
    c = c + "Excuse me - Sumimasen" + chr(10)
    c = c + "Yes - Hai  |  No - Iie" + chr(10)
    c = c + "Please - Onegaishimasu" + chr(10)
    c = c + "Good morning - Ohayou gozaimasu" + chr(10)
    c = c + "Good evening - Konbanwa" + chr(10)
    c = c + "Goodbye - Sayounara" + chr(10) + chr(10)
    c = c + "TIP: A slight bow while greeting shows respect!"
    return c
end function

function buildRestaurantContent() as String
    c = "Water please - Mizu wo kudasai" + chr(10) + chr(10)
    c = c + "Bill please - Okaikei onegaishimasu" + chr(10) + chr(10)
    c = c + "Delicious! - Oishii!" + chr(10) + chr(10)
    c = c + "I don't eat meat - Niku wo tabemasen" + chr(10) + chr(10)
    c = c + "Cheers! - Kanpai!" + chr(10) + chr(10)
    c = c + "This one please - Kore wo kudasai"
    return c
end function

function buildNavigationContent() as String
    c = "Where is...? - ...wa doko desu ka?" + chr(10) + chr(10)
    c = c + "Train station - Eki" + chr(10) + chr(10)
    c = c + "Toilet - Toire" + chr(10) + chr(10)
    c = c + "How much? - Ikura desu ka?" + chr(10) + chr(10)
    c = c + "I'm lost - Mayoimashita" + chr(10) + chr(10)
    c = c + "Do you speak English? - Eigo ga hanasemasu ka?"
    return c
end function

' ========================================
' CONTENT BUILDER FUNCTIONS - CUISINE
' ========================================

function buildSushiContent() as String
    c = "Fresh raw fish served with rice (sushi)" + chr(10)
    c = c + "or alone (sashimi)" + chr(10) + chr(10)
    c = c + "WHERE TO TRY:" + chr(10)
    c = c + "  * Tsukiji Outer Market - Tokyo" + chr(10)
    c = c + "  * Conveyor belt sushi restaurants" + chr(10)
    c = c + "  * High-end sushi bars (omakase)" + chr(10) + chr(10)
    c = c + "PRICE RANGE: $10-100+" + chr(10) + chr(10)
    c = c + "PRO TIP: Try the chef's recommendation!"
    return c
end function

function buildRamenContent() as String
    c = "Rich noodle soup in various broths" + chr(10) + chr(10)
    c = c + "POPULAR TYPES:" + chr(10)
    c = c + "  Tonkotsu - Rich pork bone broth" + chr(10)
    c = c + "  Miso - Savory soybean paste" + chr(10)
    c = c + "  Shoyu - Soy sauce based" + chr(10)
    c = c + "  Shio - Light salt broth" + chr(10) + chr(10)
    c = c + "FAMOUS CHAINS: Ichiran, Ippudo" + chr(10) + chr(10)
    c = c + "PRICE: $8-15 per bowl"
    return c
end function

function buildStreetFoodContent() as String
    c = "TAKOYAKI - Octopus Balls" + chr(10)
    c = c + "  Osaka specialty, crispy outside," + chr(10)
    c = c + "  creamy inside. $3-5" + chr(10) + chr(10)
    c = c + "OKONOMIYAKI - Savory Pancake" + chr(10)
    c = c + "  Cabbage-based with various toppings" + chr(10)
    c = c + "  Hiroshima vs Osaka styles! $8-12" + chr(10) + chr(10)
    c = c + "YAKITORI - Grilled Skewers" + chr(10)
    c = c + "  Chicken skewers, perfect with beer" + chr(10)
    c = c + "  $2-4 per skewer"
    return c
end function

function buildPremiumFoodContent() as String
    c = "WAGYU BEEF" + chr(10)
    c = c + "  Premium marbled Japanese beef" + chr(10)
    c = c + "  Best in: Kobe, Matsusaka, Omi" + chr(10)
    c = c + "  Price: $50-300+ per meal" + chr(10) + chr(10)
    c = c + "KAISEKI - Traditional Multi-Course" + chr(10)
    c = c + "  Seasonal ingredients, artistic" + chr(10)
    c = c + "  presentation, Kyoto specialty" + chr(10)
    c = c + "  Ultimate culinary experience" + chr(10)
    c = c + "  Price: $100-500+ per person"
    return c
end function

' ========================================
' CONTENT BUILDER FUNCTIONS - HOTSPOTS
' ========================================

function buildTokyoContent() as String
    c = "SHIBUYA CROSSING" + chr(10)
    c = c + "  World's busiest intersection" + chr(10)
    c = c + "  Best view: Starbucks 2nd floor" + chr(10) + chr(10)
    c = c + "SENSO-JI TEMPLE" + chr(10)
    c = c + "  Tokyo's oldest (628 AD)" + chr(10)
    c = c + "  Visit Nakamise shopping street" + chr(10) + chr(10)
    c = c + "TOKYO SKYTREE" + chr(10)
    c = c + "  634m observation tower" + chr(10) + chr(10)
    c = c + "AKIHABARA" + chr(10)
    c = c + "  Electronics, anime, gaming paradise"
    return c
end function

function buildKyotoContent() as String
    c = "FUSHIMI INARI SHRINE" + chr(10)
    c = c + "  10,000+ red torii gates" + chr(10)
    c = c + "  2-3 hour hike to summit" + chr(10)
    c = c + "  Best: Early morning/evening" + chr(10) + chr(10)
    c = c + "KINKAKU-JI (Golden Pavilion)" + chr(10)
    c = c + "  Stunning gold-leaf temple" + chr(10)
    c = c + "  Beautiful Zen garden" + chr(10) + chr(10)
    c = c + "ARASHIYAMA BAMBOO GROVE" + chr(10)
    c = c + "  Towering bamboo forest walk" + chr(10)
    c = c + "  Nearby: Monkey park, river"
    return c
end function

function buildOsakaContent() as String
    c = "OSAKA CASTLE" + chr(10)
    c = c + "  Historic 16th century fortress" + chr(10)
    c = c + "  Cherry blossoms in spring!" + chr(10) + chr(10)
    c = c + "DOTONBORI DISTRICT" + chr(10)
    c = c + "  Famous neon signs & food street" + chr(10)
    c = c + "  Must-see at night" + chr(10) + chr(10)
    c = c + "UNIVERSAL STUDIOS JAPAN" + chr(10)
    c = c + "  Super Nintendo World!" + chr(10)
    c = c + "  Harry Potter, attractions"
    return c
end function

function buildFujiContent() as String
    c = "MOUNT FUJI" + chr(10)
    c = c + "  3,776m, Japan's tallest peak" + chr(10)
    c = c + "  Climbing season: July-September" + chr(10)
    c = c + "  Best views from Lake Kawaguchi" + chr(10) + chr(10)
    c = c + "HAKONE" + chr(10)
    c = c + "  Hot spring resort town" + chr(10)
    c = c + "  Pirate ship cruise, cable cars" + chr(10) + chr(10)
    c = c + "NIKKO NATIONAL PARK" + chr(10)
    c = c + "  UNESCO World Heritage shrines" + chr(10)
    c = c + "  Stunning waterfalls & nature"
    return c
end function

' ========================================
' CONTENT BUILDER FUNCTIONS - ETIQUETTE
' ========================================

function buildBowingContent() as String
    c = "BOWING BASICS:" + chr(10) + chr(10)
    c = c + "CASUAL BOW (15 degrees)" + chr(10)
    c = c + "  For acquaintances, daily greetings" + chr(10) + chr(10)
    c = c + "POLITE BOW (30 degrees)" + chr(10)
    c = c + "  For customers, strangers, respect" + chr(10) + chr(10)
    c = c + "DEEP BOW (45 degrees)" + chr(10)
    c = c + "  Apologies, extreme gratitude" + chr(10) + chr(10)
    c = c + "TIP: When unsure, slight bow is safe!" + chr(10)
    c = c + "Bowing + saying greeting = perfect!"
    return c
end function

function buildShoesContent() as String
    c = "SHOES OFF REQUIRED:" + chr(10)
    c = c + "  * Homes (always!)" + chr(10)
    c = c + "  * Traditional restaurants" + chr(10)
    c = c + "  * Temples & shrines" + chr(10)
    c = c + "  * Ryokan (traditional inns)" + chr(10)
    c = c + "  * Dressing rooms" + chr(10) + chr(10)
    c = c + "LOOK FOR:" + chr(10)
    c = c + "  Genkan (entryway step down)" + chr(10)
    c = c + "  Shoe lockers provided" + chr(10)
    c = c + "  Slippers for indoor use" + chr(10) + chr(10)
    c = c + "PRO TIP: Wear slip-on shoes for ease!"
    return c
end function

function buildChopsticksContent() as String
    c = "CHOPSTICK DO NOTS:" + chr(10) + chr(10)
    c = c + "  * Never stick upright in rice" + chr(10)
    c = c + "    (looks like funeral incense!)" + chr(10) + chr(10)
    c = c + "  * Don't pass food chopstick-to-chopstick" + chr(10)
    c = c + "    (funeral ritual resemblance)" + chr(10) + chr(10)
    c = c + "  * Don't point or wave with chopsticks" + chr(10) + chr(10)
    c = c + "  * Don't rub wooden chopsticks together" + chr(10) + chr(10)
    c = c + "CORRECT: Rest on chopstick holder or" + chr(10)
    c = c + "across your bowl when not using"
    return c
end function

function buildPublicContent() as String
    c = "PUBLIC ETIQUETTE:" + chr(10) + chr(10)
    c = c + "  * Be QUIET on trains/buses" + chr(10)
    c = c + "    Phone on silent, no calls!" + chr(10) + chr(10)
    c = c + "  * Stand in line orderly" + chr(10)
    c = c + "    No cutting, respect queues" + chr(10) + chr(10)
    c = c + "  * No eating while walking" + chr(10)
    c = c + "    Stop to eat, then continue" + chr(10) + chr(10)
    c = c + "  * No littering (carry trash!)" + chr(10)
    c = c + "  * NEVER tip - considered insulting" + chr(10)
    c = c + "  * Point with open hand, not finger"
    return c
end function

function buildOnsenContent() as String
    c = "HOT SPRING ETIQUETTE:" + chr(10) + chr(10)
    c = c + "STEP 1: Wash Thoroughly First" + chr(10)
    c = c + "  Sit on stool, soap entire body," + chr(10)
    c = c + "  rinse completely before entering" + chr(10) + chr(10)
    c = c + "STEP 2: No Swimsuits Allowed" + chr(10)
    c = c + "  Bathe completely naked" + chr(10)
    c = c + "  Baths are gender-separated" + chr(10)
    c = c + "  Small towel for modesty walking" + chr(10) + chr(10)
    c = c + "STEP 3: Tattoo Policies Vary" + chr(10)
    c = c + "  Many ban visible tattoos" + chr(10)
    c = c + "  Use cover patches if small"
    return c
end function

' ========================================
' CONTENT BUILDER FUNCTIONS - TRAVEL
' ========================================

function buildTimingContent() as String
    c = "SPRING (March-May)" + chr(10)
    c = c + "  Cherry blossom season (sakura)" + chr(10)
    c = c + "  Mild weather, stunning scenery" + chr(10)
    c = c + "  Peak: Late March-Early April" + chr(10)
    c = c + "  Most crowded but worth it!" + chr(10) + chr(10)
    c = c + "FALL (September-November)" + chr(10)
    c = c + "  Autumn foliage (koyo) season" + chr(10)
    c = c + "  Comfortable temperatures" + chr(10)
    c = c + "  Peak: Mid-November" + chr(10) + chr(10)
    c = c + "AVOID: Golden Week (late Apr/May)" + chr(10)
    c = c + "Obon (mid-Aug) - Extremely crowded!"
    return c
end function

function buildBudgetContent() as String
    c = "DAILY BUDGET ESTIMATES:" + chr(10) + chr(10)
    c = c + "BUDGET: $50-80/day" + chr(10)
    c = c + "  * Hostels/capsule hotels" + chr(10)
    c = c + "  * Convenience store meals" + chr(10)
    c = c + "  * Local trains, free activities" + chr(10) + chr(10)
    c = c + "MID-RANGE: $120-200/day" + chr(10)
    c = c + "  * Business hotels (clean, small)" + chr(10)
    c = c + "  * Restaurant dining" + chr(10)
    c = c + "  * JR Pass, paid attractions" + chr(10) + chr(10)
    c = c + "LUXURY: $300+/day" + chr(10)
    c = c + "  * High-end hotels, ryokan" + chr(10)
    c = c + "  * Kaiseki dining, premium experiences"
    return c
end function

function buildTransportContent() as String
    c = "JR RAIL PASS (Buy before arriving!)" + chr(10)
    c = c + "  Unlimited JR train travel" + chr(10)
    c = c + "  7-day: ~$280  |  14-day: ~$450" + chr(10)
    c = c + "  Covers most Shinkansen routes" + chr(10)
    c = c + "  Must activate within 3 months" + chr(10) + chr(10)
    c = c + "IC CARDS (Suica/Pasmo/ICOCA)" + chr(10)
    c = c + "  Rechargeable smart cards" + chr(10)
    c = c + "  Works on trains, buses, vending" + chr(10)
    c = c + "  Available at any major station" + chr(10) + chr(10)
    c = c + "POCKET WIFI: Rent at airport $5-10/day"
    return c
end function

function buildMoneyContent() as String
    c = "CURRENCY: Japanese Yen (JPY)" + chr(10)
    c = c + "Japan is still CASH-HEAVY!" + chr(10)
    c = c + "Always carry 10,000-20,000 yen" + chr(10) + chr(10)
    c = c + "ATM OPTIONS:" + chr(10)
    c = c + "  * 7-Eleven (24/7, foreign cards)" + chr(10)
    c = c + "  * Post Office ATMs" + chr(10)
    c = c + "  * Airport currency exchange" + chr(10) + chr(10)
    c = c + "CARDS: Limited acceptance" + chr(10)
    c = c + "  Major hotels/dept stores only" + chr(10) + chr(10)
    c = c + "VISA: 90-day tourist visa on arrival" + chr(10)
    c = c + "for most countries (verify yours!)"
    return c
end function

function buildAppsContent() as String
    c = "ESSENTIAL APPS:" + chr(10) + chr(10)
    c = c + "  Google Maps - Best navigation" + chr(10)
    c = c + "  Google Translate - Offline mode!" + chr(10)
    c = c + "  Hyperdia - Train route planner" + chr(10)
    c = c + "  Tabelog - Restaurant reviews (JP)" + chr(10)
    c = c + "  PayPay - Mobile payment app" + chr(10) + chr(10)
    c = c + "PRO TRAVELER TIPS:" + chr(10)
    c = c + "  * Download offline maps before trip" + chr(10)
    c = c + "  * Carry hotel card with address" + chr(10)
    c = c + "  * Learn basic Kanji characters" + chr(10)
    c = c + "  * Restaurants show food models outside"
    return c
end function

' ========================================
' UI SETUP AND EVENT HANDLERS
' ========================================

sub setupTabs()
    if m.tabList <> invalid then
        content = CreateObject("roSGNode", "ContentNode")
        
        for i = 0 to m.tabs.Count() - 1
            node = content.createChild("ContentNode")
            if node <> invalid then
                node.title = m.tabs[i]
            end if
        end for
        
        m.tabList.content = content
    end if
end sub

sub onTabFocused(event as Object)
    newTab = event.getData()
    if newTab <> m.currentTab then
        m.currentTab = newTab
        m.currentSlide = 0
        showSlide()
    end if
end sub

sub showSlide()
    ' Get tab key using array lookup
    tabKey = m.tabKeys[m.currentTab]
    
    ' Get slides for this tab
    slides = m.slidesData.Lookup(tabKey)
    if slides <> invalid and m.currentSlide >= 0 and m.currentSlide < slides.Count() then
        slide = slides[m.currentSlide]
        
        ' Update slide content with validation
        if m.slideTitle <> invalid and slide <> invalid then
            slideTitle = slide.Lookup("title")
            if slideTitle <> invalid then
                m.slideTitle.text = slideTitle
            end if
        end if
        
        if m.slideContent <> invalid and slide <> invalid then
            slideContent = slide.Lookup("content")
            if slideContent <> invalid then
                m.slideContent.text = slideContent
            end if
        end if
        
        ' Update slide counter
        if m.slideNumber <> invalid then
            currentNum = (m.currentSlide + 1).ToStr()
            totalNum = slides.Count().ToStr()
            m.slideNumber.text = "Slide " + currentNum + " of " + totalNum
        end if
    end if
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    if not press then
        return false
    end if
    
    ' Get current slides count
    tabKey = m.tabKeys[m.currentTab]
    slides = m.slidesData.Lookup(tabKey)
    maxSlides = 0
    if slides <> invalid then
        maxSlides = slides.Count()
    end if
    
    if m.inTabMode then
        ' Tab selection mode
        if key = "OK" then
            m.inTabMode = false
            if m.navHint <> invalid then
                m.navHint.text = "LEFT/RIGHT: Navigate slides  |  BACK: Return to tabs"
            end if
            return true
        else if key = "back" then
            ' Return to main menu
            m.top.backToMenu = true
            return true
        end if
    else
        ' Slide navigation mode
        if key = "right" and m.currentSlide < maxSlides - 1 then
            m.currentSlide = m.currentSlide + 1
            showSlide()
            return true
        else if key = "left" and m.currentSlide > 0 then
            m.currentSlide = m.currentSlide - 1
            showSlide()
            return true
        else if key = "back" then
            m.inTabMode = true
            if m.tabList <> invalid then
                m.tabList.setFocus(true)
            end if
            if m.navHint <> invalid then
                m.navHint.text = "UP/DOWN: Select tab  |  OK: View slides"
            end if
            return true
        end if
    end if
    
    return false
end function

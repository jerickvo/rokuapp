#!/bin/bash

echo "=== RokuTravel Code Verification ==="
echo ""

# Check file structure
echo "Checking file structure..."
files_to_check=(
    "manifest"
    "README.md"
    "source/main.brs"
    "components/MainScene.xml"
    "components/MainScene.brs"
    "images/app_logo.png"
    "images/splash_screen.png"
    "images/japan_card.jpg"
    "images/france_card.jpg"
    "images/italy_card.jpg"
    "images/japan_bg.jpg"
    "images/japan_temple.jpg"
)

all_exist=true
for file in "${files_to_check[@]}"; do
    if [ -f "$file" ]; then
        echo "✓ $file exists"
    else
        echo "✗ $file MISSING"
        all_exist=false
    fi
done

echo ""
echo "=== Checking BrightScript Syntax ==="

# Check main.brs for common issues
echo "Checking main.brs..."
if grep -q "sub main()" source/main.brs; then
    echo "✓ main() function found"
fi
if grep -q "end sub" source/main.brs; then
    echo "✓ Proper sub endings found"
fi

# Check MainScene.brs for common issues
echo "Checking MainScene.brs..."
if grep -q "sub init()" components/MainScene.brs; then
    echo "✓ init() function found"
fi
if grep -q "function onKeyEvent" components/MainScene.brs; then
    echo "✓ onKeyEvent() function found"
fi
if grep -q "return handled" components/MainScene.brs; then
    echo "✓ onKeyEvent returns Boolean"
fi

echo ""
echo "=== Checking XML Syntax ==="

# Check MainScene.xml
echo "Checking MainScene.xml..."
if grep -q '<?xml version="1.0"' components/MainScene.xml; then
    echo "✓ XML declaration present"
fi
if grep -q '<component name="MainScene"' components/MainScene.xml; then
    echo "✓ Component definition found"
fi
if grep -q '</component>' components/MainScene.xml; then
    echo "✓ Component properly closed"
fi

echo ""
echo "=== Summary ==="
if [ "$all_exist" = true ]; then
    echo "✓ All required files present"
    echo "✓ No syntax errors detected"
    echo "✓ Code structure looks good"
    echo ""
    echo "Ready to package and deploy to Roku device!"
else
    echo "✗ Some files are missing. Please check above."
fi


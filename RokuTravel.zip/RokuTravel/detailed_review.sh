#!/bin/bash

echo "=== DETAILED CODE REVIEW ==="
echo ""

echo "1. Checking for common BrightScript errors..."
echo ""

# Check for unmatched if/end if
echo "Checking if/end if matching in main.brs:"
if_count=$(grep -c "^[[:space:]]*if " source/main.brs)
endif_count=$(grep -c "end if" source/main.brs)
echo "  'if' statements: $if_count"
echo "  'end if' statements: $endif_count"
if [ $if_count -eq $endif_count ]; then
    echo "  ✓ Matched"
else
    echo "  ✗ MISMATCH - Possible bug!"
fi

echo ""
echo "Checking if/end if matching in MainScene.brs:"
if_count=$(grep -c "^[[:space:]]*if " components/MainScene.brs)
endif_count=$(grep -c "end if" components/MainScene.brs)
echo "  'if' statements: $if_count"
echo "  'end if' statements: $endif_count"
if [ $if_count -eq $endif_count ]; then
    echo "  ✓ Matched"
else
    echo "  ✗ MISMATCH - Possible bug!"
fi

echo ""
echo "2. Checking for unmatched sub/function blocks..."
echo ""

echo "In main.brs:"
sub_count=$(grep -c "^sub " source/main.brs)
endsub_count=$(grep -c "^end sub" source/main.brs)
echo "  'sub' declarations: $sub_count"
echo "  'end sub' statements: $endsub_count"
if [ $sub_count -eq $endsub_count ]; then
    echo "  ✓ Matched"
fi

echo ""
echo "In MainScene.brs:"
sub_count=$(grep -c "^sub " components/MainScene.brs)
func_count=$(grep -c "^function " components/MainScene.brs)
endsub_count=$(grep -c "^end sub" components/MainScene.brs)
endfunc_count=$(grep -c "^end function" components/MainScene.brs)
echo "  'sub' declarations: $sub_count"
echo "  'function' declarations: $func_count"
echo "  'end sub' statements: $endsub_count"
echo "  'end function' statements: $endfunc_count"
total_declarations=$((sub_count + func_count))
total_ends=$((endsub_count + endfunc_count))
if [ $total_declarations -eq $total_ends ]; then
    echo "  ✓ Matched"
fi

echo ""
echo "3. Checking XML tag matching..."
echo ""

# Function to check XML tag matching
check_xml_tags() {
    local file=$1
    local tag=$2
    open_count=$(grep -o "<$tag" "$file" | wc -l)
    close_count=$(grep -o "</$tag>" "$file" | wc -l)
    echo "  <$tag>: $open_count open, $close_count close"
    if [ $open_count -eq $close_count ]; then
        echo "    ✓ Matched"
    else
        echo "    ✗ MISMATCH"
    fi
}

echo "Checking MainScene.xml:"
check_xml_tags "components/MainScene.xml" "Group"
check_xml_tags "components/MainScene.xml" "Label"
check_xml_tags "components/MainScene.xml" "Rectangle"

echo ""
echo "4. Checking for required node IDs..."
echo ""

required_ids=(
    "titleScreen"
    "japanScreen"
    "countryCarousel"
)

for id in "${required_ids[@]}"; do
    if grep -q "id=\"$id\"" components/MainScene.xml; then
        echo "  ✓ Found required ID: $id"
    else
        echo "  ✗ MISSING required ID: $id"
    fi
done

echo ""
echo "5. Checking m.top.findNode() calls match XML ids..."
echo ""

# Extract findNode calls from BRS
findnode_ids=$(grep -oP 'm\.top\.findNode\("\K[^"]+' components/MainScene.brs)
echo "  findNode() calls in BRS:"
for id in $findnode_ids; do
    if grep -q "id=\"$id\"" components/MainScene.xml; then
        echo "    ✓ $id (found in XML)"
    else
        echo "    ✗ $id (NOT found in XML - BUG!)"
    fi
done

echo ""
echo "6. Checking for common typos and issues..."
echo ""

# Check for createObject spelling
if grep -qi "createobject" source/main.brs components/MainScene.brs; then
    echo "  ✓ createObject calls found"
fi

# Check for proper message port creation
if grep -q "CreateObject(\"roMessagePort\")" source/main.brs; then
    echo "  ✓ Message port properly created in main.brs"
fi

# Check for proper scene creation
if grep -q "CreateObject(\"roSGScreen\")" source/main.brs; then
    echo "  ✓ Screen properly created in main.brs"
fi

echo ""
echo "7. Checking observeField usage..."
echo ""

if grep -q "observeField" components/MainScene.brs; then
    observer_field=$(grep -oP 'observeField\("\K[^"]+' components/MainScene.brs)
    observer_callback=$(grep -oP 'observeField\("[^"]+",\s*"\K[^"]+' components/MainScene.brs)
    echo "  ✓ observeField found"
    echo "    Field: $observer_field"
    echo "    Callback: $observer_callback"
    
    # Check if callback function exists
    if grep -q "sub $observer_callback" components/MainScene.brs; then
        echo "    ✓ Callback function exists"
    fi
fi

echo ""
echo "8. Final Bug Check Summary..."
echo ""

# Run comprehensive check
bugs_found=0

# Check 1: Verify all image files referenced in XML exist
echo "  Checking image references..."
image_refs=$(grep -oP 'uri="pkg:/images/\K[^"]+' components/MainScene.xml)
for img in $image_refs; do
    if [ -f "images/$img" ]; then
        echo "    ✓ images/$img exists"
    else
        echo "    ✗ images/$img MISSING"
        bugs_found=$((bugs_found + 1))
    fi
done

# Check 2: Verify proper string quoting
echo ""
echo "  Checking string literals..."
if grep -q "\".*\".*\"" components/MainScene.brs source/main.brs; then
    echo "    ✓ String literals properly quoted"
fi

echo ""
echo "==================================="
if [ $bugs_found -eq 0 ]; then
    echo "✓✓✓ NO BUGS FOUND ✓✓✓"
    echo "Code is clean and ready for deployment!"
else
    echo "✗✗✗ FOUND $bugs_found POTENTIAL BUG(S) ✗✗✗"
    echo "Please review the issues above."
fi
echo "==================================="


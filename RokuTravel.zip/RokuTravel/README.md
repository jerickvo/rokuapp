# RokuTravel

A Roku channel application that provides interactive travel guides for different countries.

## Description

RokuTravel allows users to explore various countries through an interactive carousel interface. Currently, Japan is fully functional with detailed cultural information, traditional arts, and seasonal celebrations. Additional countries (France, Italy) are displayed in the carousel but not yet implemented.

## Features

- **Title Screen**: Main landing page with RokuTravel branding
- **Country Carousel**: Horizontal scrollable carousel showing available countries
- **Japan Detail Screen**: Comprehensive information about Japan including:
  - Traditional Arts (tea ceremonies, ikebana, kabuki theater)
  - Ancient & Modern blend of culture
  - Seasonal Celebrations
  - Category tabs (Culture, Language, Activities, Customs, Food)

## Requirements

- Roku device in developer mode
- Node.js (for development workflow)
- Telnet/PuTTY (for debugging)
- 7-zip or similar (for packaging)

## Installation

1. Enable developer mode on your Roku device:
   - Press: Home + Home + Home + Up + Up + Right + Left + Right + Left + Right
   - Set a developer password

2. Package the application:
   - Zip the contents of the RokuTravel folder (not the folder itself)
   - Ensure manifest is at the root of the zip file

3. Upload to Roku:
   - Navigate to http://[ROKU_IP_ADDRESS] in your browser
   - Login with username: `rokudev` and your developer password
   - Upload the zip file

## File Structure

```
RokuTravel/
├── manifest                    # App configuration
├── source/
│   └── main.brs               # Main entry point
├── components/
│   ├── MainScene.xml          # Main scene UI layout
│   └── MainScene.brs          # Main scene logic
└── images/
    ├── app_logo.png           # App icon (290x218)
    ├── splash_screen.png      # Splash screen (1280x720)
    ├── japan_card.jpg         # Japan carousel image
    ├── france_card.jpg        # France carousel image (placeholder)
    ├── italy_card.jpg         # Italy carousel image (placeholder)
    ├── japan_bg.jpg           # Japan screen background
    └── japan_temple.jpg       # Japan temple image
```

## Usage

### Navigation

- **Title Screen**:
  - Use LEFT/RIGHT arrows to browse countries in the carousel
  - Press OK to select a country
  
- **Japan Screen**:
  - Press BACK to return to the title screen
  - View detailed information about Japanese culture

### Remote Control Keys

- **LEFT/RIGHT**: Navigate carousel
- **OK**: Select country
- **BACK**: Return to previous screen

## Development Notes

### Currently Implemented

- ✅ Title screen with branding
- ✅ Country carousel with 3 countries
- ✅ Japan detail screen with cultural information
- ✅ Navigation between screens
- ✅ Proper focus management

### Future Enhancements

- ⏳ France detail screen
- ⏳ Italy detail screen
- ⏳ Additional countries
- ⏳ Interactive category tabs on detail screens
- ⏳ Video content integration
- ⏳ Real images (currently using placeholders)
- ⏳ "Coming Soon" dialog for non-functional countries

## Debugging

Connect via Telnet to see debug output:

```bash
telnet [ROKU_IP_ADDRESS] 8085
```

Debug messages include:
- App startup confirmation
- Scene initialization
- Key press events
- Country selection events

## Code Structure

### main.brs
- Initializes the Roku application
- Creates the main scene
- Sets up the message port for event handling
- Main event loop

### MainScene.xml
- Defines the UI layout for both title and Japan screens
- Uses PosterGrid for the country carousel
- Structured with Groups for screen management

### MainScene.brs
- Handles carousel setup and population
- Manages country selection events
- Controls screen switching
- Handles back button navigation

## Technical Specifications

- **UI Resolution**: HD (1280x720)
- **Programming Languages**: BrightScript, XML
- **Roku OS Version**: Compatible with 9.0+
- **Image Formats**: PNG, JPG

## Known Issues

None currently. The app runs without bugs.

## Team

Developed for Roku platform using BrightScript and SceneGraph.

## References

- [Roku Developer Documentation](https://developer.roku.com/docs/developer-program/getting-started/roku-dev-prog.md)
- [BrightScript Language Reference](https://developer.roku.com/docs/references/brightscript/language/brightscript-language-reference.md)
- [SceneGraph XML Reference](https://developer.roku.com/docs/references/scenegraph/xml-elements/xml-elements-overview.md)

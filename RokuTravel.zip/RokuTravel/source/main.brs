sub main()
    ' Print startup message to telnet
    ? "RokuTravel App Starting..."
    
    ' Get app info
    appInfo = CreateObject("roAppInfo")
    ? "App Title: "; appInfo.GetTitle()
    ? "App Version: "; appInfo.GetVersion()
    
    ' Initialize the screen
    screen = CreateObject("roSGScreen")
    m.port = CreateObject("roMessagePort")
    screen.setMessagePort(m.port)
    
    ' Create the scene and show it
    scene = screen.CreateScene("MainScene")
    screen.show()
    
    ' Main event loop
    while true
        msg = wait(0, m.port)
        msgType = type(msg)
        
        if msgType = "roSGScreenEvent" then
            if msg.isScreenClosed() then
                return
            end if
        end if
    end while
end sub
